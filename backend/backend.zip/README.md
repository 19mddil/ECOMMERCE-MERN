# init
```bash
    npm i express bcrypt cors dotenv joi jsonwebtoken lodash
    npm install morgan --save-dev
```