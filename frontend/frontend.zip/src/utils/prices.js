export const prices = [
    {
        id: 0,
        name: "Any",
        arr: []
    },
    {
        id: 1,
        name: "0 to 1000",
        arr: [0, 1000]
    },
    {
        id: 2,
        name: "1000 to 2000",
        arr: [1000, 2000]
    },
    {
        id: 3,
        name: "2000 to 3000",
        arr: [2000, 3000]

    },
    {
        id: 4,
        name: "3000 to 4000",
        arr: [3000, 4000]
    },
    {
        id: 5,
        name: "More than 4000",
        arr: [4000, 100000]
    }
]